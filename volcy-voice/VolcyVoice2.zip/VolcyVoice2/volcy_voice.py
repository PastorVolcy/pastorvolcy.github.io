#!/usr/bin/env python3
"""Volcy Voice 2: private, unlimited, offline dictation for macOS.

Hold Right Option and talk, then let go and the text is typed wherever your cursor is.
Double-tap Right Option for hands-free mode, and tap it again to finish. Esc cancels.
Open the dashboard from the menu bar to see history (with Copy buttons), your dictionary, and settings.

Run `python volcy_voice.py --test` to record 5 seconds and print the transcript (diagnostics).
"""
import json, logging, platform, queue, re, sqlite3, subprocess, sys, threading, time, traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import numpy as np

HOME = Path.home() / ".volcy_voice"
HOME.mkdir(exist_ok=True)
CONFIG = HOME / "config.json"
VOCAB = HOME / "vocabulary.txt"
REPL = HOME / "replacements.txt"
DB = HOME / "history.db"
LOG = HOME / "log.txt"
VERSION = "2.3"
UPDATE_BASE = "https://pastorvolcy.github.io/volcy-voice/"

logging.basicConfig(filename=str(LOG), level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("volcy")

DEFAULTS = {
    "engine": "auto",                 # auto | mlx | faster
    "model_mlx": "mlx-community/whisper-large-v3-turbo",
    "model_faster": "small.en",       # Intel Macs: base.en (fastest), small.en (balanced), large-v3-turbo (most accurate, slow)
    "beam_size": 1,
    "cloud": False,                   # True = Groq Whisper large-v3 (instant), falls back to local if offline
    "cloud_model": "whisper-large-v3-turbo",
    "config_version": 2,
    "language": "en",                 # en, es, fr, ht, auto
    "hotkey_label": "",
    "hotkey": "alt_r",                # alt_r (Right Option), cmd_r, ctrl_r, f13
    "mode": "release",                # release = type when I let go; live = type as I speak (at each pause)
    "remove_fillers": True,
    "voice_commands": True,           # "new line", "new paragraph"
    "input_device": "auto",           # auto = MacBook mic if present, else system default; or a device name
    "silence_threshold": 0.004,
    "live_pause": 0.7,                # seconds of silence that ends a phrase in live mode
    "restore_clipboard": True,
    "sounds": True,
    "start_sound": "Thump",
    "stop_sound": "Tick",
    "sound_volume": 0.8,
    "port": 7788,
    "typing_wpm": 40,                 # used for "time saved"
}
DEFAULT_VOCAB = """First Alliance Church
Pastor Ricardo Volcy
Christian and Missionary Alliance
Harrisburg
Preacher's Podium
Holy Spirit
Pentecost
Habakkuk, Zephaniah, Haggai, Zechariah, Malachi, Nehemiah, Ecclesiastes, Deuteronomy, Leviticus
Melchizedek, Nebuchadnezzar, Barnabas, Silas, Timothy, Priscilla, Aquila
hallelujah, hosanna, sanctification, justification, propitiation, atonement
"""
DEFAULT_REPL = """# One per line:  heard => written
first alliance => First Alliance
pastor volcy => Pastor Volcy
"""


def load_config():
    cfg = dict(DEFAULTS)
    if CONFIG.exists():
        try:
            old = json.loads(CONFIG.read_text(encoding="utf-8"))
            if old.get("config_version", 1) < 2:      # v1 used large-v3-turbo on Intel: ~20 s per sentence
                old.pop("model_faster", None)
                old.pop("silence_threshold", None)
                old["config_version"] = 2
            cfg.update(old)
        except Exception:
            log.exception("bad config")
    CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    if not VOCAB.exists():
        VOCAB.write_text(DEFAULT_VOCAB, encoding="utf-8")
    if not REPL.exists():
        REPL.write_text(DEFAULT_REPL, encoding="utf-8")
    return cfg


CFG = load_config()


def save_config():
    CONFIG.write_text(json.dumps(CFG, indent=2), encoding="utf-8")


SR = 16000
APPLE_SILICON = platform.machine() == "arm64"

# ---------------------------------------------------------------- text cleanup
FILLER_RE = re.compile(r"(?i),?\s*(?<![\w'-])(?:u+h+m*|u+m+|e+r+m+|e+r{2,}|a+h+|h+m+|m{2,}|uh-huh)(?![\w'-])[,…]*(?:\.\.\.)?")
KEEP_REPEATS = {"had", "that", "very", "no", "so", "bye", "yeah", "really", "ha", "holy", "well",
                "go", "come", "yes", "more", "far", "long", "is"}
PHRASE_RE = re.compile(r"(?i)\b((?:\w+[' ]+){1,5}\w+)(?:\s*(?:,|\.\.\.|…|-+)\s*|\s+)\1\b")
REPEAT_RE = re.compile(r"(?i)\b(\w+)((?:[ ,]+\1\b)+)")
HALLUCINATIONS = {"thank you", "thanks for watching", "you", "bye", "thank you for watching",
                  "thank you so much for watching", "subtitles by the amara.org community", "so", "okay"}


def load_replacements():
    out = []
    for line in REPL.read_text(encoding="utf-8").splitlines():
        if "=>" in line and not line.strip().startswith("#"):
            a, b = line.split("=>", 1)
            if a.strip():
                out.append((re.compile(r"(?i)\b" + re.escape(a.strip()) + r"\b"), b.strip()))
    return out


def _cap(m):
    return m.group(1) + m.group(2).upper()


def clean(text, fillers=None, commands=None):
    fillers = CFG["remove_fillers"] if fillers is None else fillers
    commands = CFG["voice_commands"] if commands is None else commands
    t = " " + (text or "").strip() + " "
    if fillers:
        t = FILLER_RE.sub(" ", t)
        t = re.sub(r"(?i)\byou know,\s*", "", t) if t.strip().lower().startswith("you know,") else t
        t = re.sub(r"(?i)(^|[.?!]\s+|\n)\s*(?:(?:so|okay|ok|well|alright|all right|now),\s+)+(?=\w)", r"\1", t)
        t = re.sub(r"(?i),\s*(?:you know|i mean|like|sort of|kind of|basically|actually)\s*,", " ", t)
        t = re.sub(r"(?i)(^|[.?!]\s+)\s*(?:you know|i mean|like|basically|actually),\s*", r"\1", t)
        for _ in range(2):   # false starts: "I went to the, I went to the store" -> "I went to the store"
            t = PHRASE_RE.sub(r"\1", t)
        t = REPEAT_RE.sub(lambda m: m.group(0) if m.group(1).lower() in KEEP_REPEATS else m.group(1), t)
    if commands:
        t = re.sub(r"(?i),?\s*\bnew paragraph\b[,.]?\s*", "\n\n", t)
        t = re.sub(r"(?i),?\s*\bnew line\b[,.]?\s*", "\n", t)
    for rx, rep in load_replacements():
        t = rx.sub(rep, t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r" +([,.;:?!])", r"\1", t)
    t = re.sub(r"([,;:])\1+", r"\1", t)
    t = re.sub(r"([.?!])(?:\s+[.,]+)+", r"\1", t)
    t = re.sub(r"(?<!\.)([.?!])[.,](?!\.)", r"\1", t)     # "church. ." left by a removed "Uh."
    t = re.sub(r",\s*([.?!])", r"\1", t)
    t = re.sub(r"^[\s,.;:]+", "", t)          # a filler at the start can leave ", "
    t = re.sub(r" *\n *", "\n", t)
    t = t.strip(" ")
    t = re.sub(r"(^|[.?!]\s+|\n)([a-z])", _cap, t)
    return t


def is_hallucination(text):
    return re.sub(r"[^\w\s.]", "", text).strip(" .").lower() in HALLUCINATIONS


# ---------------------------------------------------------------- audio
def resample(a, src):
    if src == SR or len(a) == 0:
        return a.astype(np.float32)
    n = int(round(len(a) * SR / src))
    x = np.linspace(0, len(a) - 1, n)
    return np.interp(x, np.arange(len(a)), a).astype(np.float32)


def list_inputs():
    import sounddevice as sd
    return [(i, d["name"]) for i, d in enumerate(sd.query_devices()) if d["max_input_channels"] > 0]


def pick_device():
    want = CFG.get("input_device", "auto")
    devs = list_inputs()
    if want and want not in ("auto", "default"):
        for i, n in devs:
            if n == want:
                return i
    if want == "auto":
        for i, n in devs:
            if "macbook" in n.lower() and "microphone" in n.lower():
                return i
    return None


class Recorder:
    BLOCK = 0.03

    def __init__(self):
        self.stream = None
        self.lock = threading.Lock()
        self.blocks, self.rms, self.cut, self.sr = [], [], 0, SR
        self.device_name = ""

    def start(self):
        import sounddevice as sd
        dev = pick_device()
        info = sd.query_devices(dev, "input") if dev is not None else sd.query_devices(kind="input")
        self.device_name = info["name"]
        self.sr = int(info["default_samplerate"]) or 48000
        with self.lock:
            self.blocks, self.rms, self.cut = [], [], 0
        self.stream = sd.InputStream(device=dev, samplerate=self.sr, channels=1, dtype="float32",
                                     blocksize=int(self.sr * self.BLOCK), callback=self._cb)
        self.stream.start()

    def _cb(self, data, frames, t, status):
        b = data[:, 0].copy()
        r = float(np.sqrt(np.mean(b * b))) if len(b) else 0.0
        with self.lock:
            self.blocks.append(b)
            self.rms.append(r)

    def stop(self):
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                log.exception("stream stop")
            self.stream = None

    def take(self, upto=None):
        with self.lock:
            end = len(self.blocks) if upto is None else upto
            seg, rms = self.blocks[self.cut:end], self.rms[self.cut:end]
            self.cut = end
        if not seg:
            return None, 0.0
        return resample(np.concatenate(seg), self.sr), max(rms)


# ---------------------------------------------------------------- speech engine
class Engine:
    """Lives on ONE thread: load and transcribe on the same thread (MLX requires this)."""

    def __init__(self):
        k = CFG["engine"]
        self.kind = ("mlx" if APPLE_SILICON else "faster") if k == "auto" else k
        self.model = None

    def load(self):
        if self.kind == "mlx":
            import mlx_whisper
            self.mod = mlx_whisper
            self.mod.transcribe(np.zeros(SR, dtype=np.float32), path_or_hf_repo=CFG["model_mlx"])
        else:
            import os
            from faster_whisper import WhisperModel
            name = CFG["model_faster"]
            if name.endswith(".en") and CFG["language"] != "en":
                name = name[:-3]                      # English-only models can't do other languages
            self.model = WhisperModel(name, device="cpu", compute_type="int8",
                                      cpu_threads=os.cpu_count() or 4)
            list(self.model.transcribe(np.zeros(SR, dtype=np.float32), beam_size=1)[0])  # warm up

    def prompt(self):
        words = ", ".join(l.strip() for l in VOCAB.read_text(encoding="utf-8").splitlines() if l.strip())
        return ("Clear, well punctuated notes from Pastor Volcy. " + words)[:700]

    def transcribe(self, audio):
        m = float(np.max(np.abs(audio))) if len(audio) else 0.0
        if 0.0005 < m < 0.5:                      # quiet mic (AirPods): boost so Whisper hears it
            audio = (audio * (0.6 / m)).astype(np.float32)
        lang = None if CFG["language"] == "auto" else CFG["language"]
        self.used = self.kind
        if CFG.get("cloud"):
            key = get_key()
            if key:
                try:
                    t = cloud_transcribe(audio, self.prompt(), key)
                    self.used = "cloud"
                    return t
                except Exception as e:
                    log.warning("cloud failed, using local: %s", e)
        if self.kind == "mlx":
            r = self.mod.transcribe(audio, path_or_hf_repo=CFG["model_mlx"], language=lang,
                                    initial_prompt=self.prompt(), condition_on_previous_text=False,
                                    temperature=0.0)
            return (r.get("text") or "").strip()
        segs, _ = self.model.transcribe(audio, language=lang, initial_prompt=self.prompt(),
                                        beam_size=int(CFG.get("beam_size", 1)), vad_filter=True, without_timestamps=True,
                                        condition_on_previous_text=False)
        return " ".join(s.text.strip() for s in segs).strip()


# ---------------------------------------------------------------- cloud (Groq)
KEY_SERVICE = "volcy-voice-groq"


def get_key():
    try:
        r = subprocess.run(["security", "find-generic-password", "-s", KEY_SERVICE, "-w"],
                           capture_output=True, text=True, timeout=5)
        return r.stdout.strip() or None
    except Exception:
        return None


def set_key(k):
    subprocess.run(["security", "add-generic-password", "-U", "-s", KEY_SERVICE, "-a", "groq", "-w", k],
                   capture_output=True, timeout=5)


def wav_bytes(audio):
    import io, wave
    pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm)
    return buf.getvalue()


def cloud_transcribe(audio, prompt, key):
    import urllib.request, uuid
    b = uuid.uuid4().hex
    fields = {"model": CFG["cloud_model"], "prompt": prompt[:800], "temperature": "0", "response_format": "json"}
    if CFG["language"] != "auto":
        fields["language"] = CFG["language"]
    body = b""
    for k, v in fields.items():
        body += f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
    body += f'--{b}\r\nContent-Disposition: form-data; name="file"; filename="a.wav"\r\nContent-Type: audio/wav\r\n\r\n'.encode()
    body += wav_bytes(audio) + f"\r\n--{b}--\r\n".encode()
    req = urllib.request.Request("https://api.groq.com/openai/v1/audio/transcriptions", data=body, method="POST",
                                 headers={"Authorization": f"Bearer {key}", "User-Agent": "VolcyVoice/2",
                                          "Content-Type": f"multipart/form-data; boundary={b}"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return (json.loads(r.read()).get("text") or "").strip()


# ---------------------------------------------------------------- history
class History:
    def __init__(self):
        self.lock = threading.Lock()
        self.db = sqlite3.connect(str(DB), check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS d(id INTEGER PRIMARY KEY, session TEXT UNIQUE,
            ts REAL, text TEXT, raw TEXT, app TEXT, words INTEGER, audio REAL, latency REAL)""")
        self.db.commit()

    def add(self, session, text, raw, app, audio, latency):
        with self.lock:
            row = self.db.execute("SELECT id,text,raw,audio FROM d WHERE session=?", (session,)).fetchone()
            if row:
                sep = "" if row[1].endswith("\n") else " "
                t, r = row[1] + sep + text, row[2] + " " + raw
                self.db.execute("UPDATE d SET text=?,raw=?,words=?,audio=?,latency=? WHERE id=?",
                                (t, r, len(t.split()), row[3] + audio, latency, row[0]))
            else:
                self.db.execute("INSERT INTO d(session,ts,text,raw,app,words,audio,latency) VALUES(?,?,?,?,?,?,?,?)",
                                (session, time.time(), text, raw, app, len(text.split()), audio, latency))
            self.db.commit()

    def recent(self, limit=50, q=""):
        with self.lock:
            if q:
                rows = self.db.execute("SELECT id,ts,text,app,words,latency FROM d WHERE text LIKE ? ORDER BY ts DESC LIMIT ?",
                                       ("%" + q + "%", limit)).fetchall()
            else:
                rows = self.db.execute("SELECT id,ts,text,app,words,latency FROM d ORDER BY ts DESC LIMIT ?",
                                       (limit,)).fetchall()
        return [dict(id=r[0], ts=r[1], text=r[2], app=r[3] or "", words=r[4], latency=r[5]) for r in rows]

    def get(self, i):
        with self.lock:
            r = self.db.execute("SELECT text FROM d WHERE id=?", (i,)).fetchone()
        return r[0] if r else None

    def delete(self, i):
        with self.lock:
            self.db.execute("DELETE FROM d WHERE id=?", (i,))
            self.db.commit()

    def stats(self):
        with self.lock:
            n, w, a, lat = self.db.execute("SELECT COUNT(*),COALESCE(SUM(words),0),COALESCE(SUM(audio),0),AVG(latency) FROM d").fetchone()
        saved = max(0.0, w / CFG["typing_wpm"] * 60 - a)
        return dict(count=n, words=w, saved_min=round(saved / 60), avg_latency=round(lat or 0, 2))

    def export(self):
        return "\n\n".join(time.strftime("%Y-%m-%d %H:%M", time.localtime(r["ts"])) + "\n" + r["text"]
                           for r in reversed(self.recent(100000)))


# ---------------------------------------------------------------- typing into apps
def get_clip():
    try:
        from AppKit import NSPasteboard
        return NSPasteboard.generalPasteboard().stringForType_("public.utf8-plain-text")
    except Exception:
        return None


def set_clip(s):
    subprocess.run(["pbcopy"], input=s.encode("utf-8"))


def cmd_v():
    try:
        from Quartz import (CGEventCreateKeyboardEvent, CGEventPost, CGEventSetFlags,
                            kCGEventFlagMaskCommand, kCGHIDEventTap)
        for down in (True, False):
            e = CGEventCreateKeyboardEvent(None, 9, down)  # 9 = V
            CGEventSetFlags(e, kCGEventFlagMaskCommand)
            CGEventPost(kCGHIDEventTap, e)
            time.sleep(0.01)
    except Exception:
        log.exception("Quartz paste failed, falling back to System Events")
        subprocess.run(["osascript", "-e", 'tell application "System Events" to keystroke "v" using command down'])


TYPE_LOCK = threading.Lock()


def type_text(text):
    with TYPE_LOCK:
        old = get_clip() if CFG["restore_clipboard"] else None
        set_clip(text)
        time.sleep(0.05)
        cmd_v()
        if old is not None:
            time.sleep(0.4)
            set_clip(old)


CONTINUE_WORDS = {"and", "but", "or", "so", "because", "which", "who", "that", "to", "of", "in", "with",
                  "for", "when", "while", "if", "as", "than", "until", "unless", "where", "whereas", "since",
                  "though", "although", "plus", "nor", "yet", "into", "onto", "from", "about", "after",
                  "before", "by", "at", "on", "is", "are", "was", "were", "will", "would", "can", "could"}
LOWER_OK = CONTINUE_WORDS | {"the", "a", "an", "this", "these", "those", "it", "its", "we", "you", "he", "she", "they",
                             "my", "our", "your", "his", "her", "their", "there", "here", "all", "not", "just", "also"}


def char_before_cursor():
    """The character left of the text cursor in the focused field: '' at the start, None if unknown."""
    try:
        from ApplicationServices import (AXUIElementCreateSystemWide, AXUIElementCopyAttributeValue,
                                         AXValueGetValue, kAXValueCFRangeType)
        err, el = AXUIElementCopyAttributeValue(AXUIElementCreateSystemWide(), "AXFocusedUIElement", None)
        if err or el is None:
            return None
        err, rng = AXUIElementCopyAttributeValue(el, "AXSelectedTextRange", None)
        if err or rng is None:
            return None
        ok, r = AXValueGetValue(rng, kAXValueCFRangeType, None)
        loc = r[0] if not hasattr(r, "location") else r.location
        if not ok:
            return None
        if loc == 0:
            return ""
        err, val = AXUIElementCopyAttributeValue(el, "AXValue", None)
        if err or not isinstance(val, str) or loc > len(val):
            return None
        return val[loc - 1]
    except Exception:
        return None


def fit_to_cursor(text):
    """Add a leading space or lowercase the first word so a dictation joins the text already there."""
    if not text:
        return text
    c = char_before_cursor()
    if not c:
        return text
    first = re.match(r"[A-Za-z']+", text)
    if (c.isalnum() or c in ",;:") and first and first.group(0).lower() in LOWER_OK and text[:2] != "I ":
        text = text[0].lower() + text[1:]
    if not c.isspace() and c not in "([{\"'“‘/-" and (text[0].isalnum() or text[0] in "\"'“‘("):
        text = " " + text
    return text


def front_app():
    try:
        from AppKit import NSWorkspace
        return str(NSWorkspace.sharedWorkspace().frontmostApplication().localizedName())
    except Exception:
        return ""


APPDIR = Path.home() / "VolcyVoice"
_SOUNDS = {}
CUSTOM_SOUNDS = {"Thump": "thump.wav", "Tick": "tick.wav", "Click": "click.wav", "Blip": "blip.wav",
                 "Woodblock": "wood.wav", "Drop": "drop.wav"}
SYSTEM_SOUNDS = ["Tink", "Pop", "Morse", "Purr", "Bottle", "Frog", "Submarine", "Glass", "Hero", "Ping"]
SOUND_CHOICES = list(CUSTOM_SOUNDS) + SYSTEM_SOUNDS + ["None"]


def sound(name, force=False):
    if (not CFG["sounds"] and not force) or not name or name == "None":
        return
    path = APPDIR / CUSTOM_SOUNDS[name] if name in CUSTOM_SOUNDS else Path(f"/System/Library/Sounds/{name}.aiff")
    if not path.exists():
        return
    try:
        from AppKit import NSSound
        s = _SOUNDS.get(name)
        if s is None:
            s = _SOUNDS[name] = NSSound.alloc().initWithContentsOfFile_byReference_(str(path), True)
        s.stop()
        s.setVolume_(float(CFG.get("sound_volume", 0.8)))
        s.play()
    except Exception:
        subprocess.Popen(["afplay", str(path)])


# ---------------------------------------------------------------- hotkey helpers
KEY_NAMES = {"alt_r": "Right Option", "alt": "Left Option", "alt_l": "Left Option", "cmd_r": "Right Command",
             "cmd": "Left Command", "cmd_l": "Left Command", "ctrl_r": "Right Control", "ctrl": "Left Control",
             "ctrl_l": "Left Control", "shift_r": "Right Shift", "shift": "Left Shift", "shift_l": "Left Shift",
             "caps_lock": "Caps Lock", "esc": "Esc", "space": "Space", "tab": "Tab", "page_down": "Page Down",
             "page_up": "Page Up", "home": "Home", "end": "End", "media_play_pause": "Play/Pause"}


def parse_hotkey(s):
    from pynput import keyboard
    s = s or "alt_r"
    if s.startswith("vk:"):
        return keyboard.KeyCode.from_vk(int(s[3:]))
    if s.startswith("char:"):
        return keyboard.KeyCode.from_char(s[5:])
    return getattr(keyboard.Key, s, keyboard.Key.alt_r)


def key_to_str(key):
    name = getattr(key, "name", None)
    if name:
        return name
    vk = getattr(key, "vk", None)
    if vk is not None:
        return f"vk:{vk}"
    return f"char:{getattr(key, 'char', '') or '?'}"


def key_label(s, key=None):
    s = s or "alt_r"
    if s in KEY_NAMES:
        return KEY_NAMES[s]
    if re.fullmatch(r"f\d+", s):
        return s.upper()
    ch = getattr(key, "char", None) if key is not None else None
    if ch:
        return ch.upper()
    if s.startswith("char:"):
        return s[5:].upper()
    if s.startswith("vk:"):
        return f"Key #{s[3:]}"
    return s.replace("_", " ").title()


def same_key(a, b):
    if a == b:
        return True
    va, vb = getattr(a, "vk", None), getattr(b, "vk", None)
    if va is not None and vb is not None and not getattr(a, "name", None) and not getattr(b, "name", None):
        return va == vb
    return False


def mic_status():
    """authorized | denied | undetermined | unknown"""
    try:
        from AVFoundation import AVCaptureDevice, AVMediaTypeAudio
        return {0: "undetermined", 1: "denied", 2: "denied", 3: "authorized"}.get(
            int(AVCaptureDevice.authorizationStatusForMediaType_(AVMediaTypeAudio)), "unknown")
    except Exception:
        return "unknown"


def request_mic():
    try:
        from AVFoundation import AVCaptureDevice, AVMediaTypeAudio
        AVCaptureDevice.requestAccessForMediaType_completionHandler_(AVMediaTypeAudio, lambda ok: log.info("mic access %s", ok))
    except Exception:
        log.exception("request mic")


def accessibility_ok():
    try:
        from ApplicationServices import AXIsProcessTrusted
        return bool(AXIsProcessTrusted())
    except Exception:
        return True


# ---------------------------------------------------------------- dashboard
DASH = APPDIR / "dashboard.html" if (APPDIR / "dashboard.html").exists() else Path(__file__).resolve().parent / "dashboard.html"


def diagnostics(app):
    try:
        lines = LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-80:]
    except Exception:
        lines = []
    head = [f"Volcy Voice {VERSION}", f"Mac: {platform.machine()} {platform.mac_ver()[0]}",
            f"Status: {getattr(app, 'status_text', '')}", f"Accessibility: {getattr(app, 'trusted', '?')}",
            f"Microphone: {mic_status()}", f"Key: {CFG.get('hotkey')}  Mode: {CFG.get('mode')}  "
            f"Model: {CFG.get('model_faster')}  Instant: {CFG.get('cloud')}", "", "Last log lines:"]
    return "\n".join(head + lines)


def check_update():
    import urllib.request
    try:
        with urllib.request.urlopen(UPDATE_BASE + "version.json", timeout=8) as r:
            info = json.loads(r.read().decode())
        latest = str(info.get("version", ""))
        newer = tuple(int(x) for x in latest.split(".")) > tuple(int(x) for x in VERSION.split("."))
        return {"ok": True, "current": VERSION, "latest": latest, "newer": newer, "notes": info.get("notes", "")}
    except Exception as e:
        return {"ok": False, "current": VERSION, "error": str(e)[:120]}


def start_update():
    """Download the latest build and run its installer, which restarts the app."""
    script = (
        'set -e; T=$(mktemp -d); cd "$T"; '
        f'curl -fsSL "{UPDATE_BASE}VolcyVoice2.zip" -o v.zip; unzip -q -o v.zip; '
        'bash VolcyVoice2/install.command >> "$HOME/.volcy_voice/update.log" 2>&1'
    )
    try:
        subprocess.Popen(["/bin/bash", "-c", script], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log.info("update started")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def make_handler(app):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, body, ctype="application/json", code=200, extra=None):
            if not isinstance(body, (bytes, bytearray)):
                body = json.dumps(body).encode() if ctype == "application/json" else body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}")

        def do_GET(self):
            self._safe(self._get)

        def _safe(self, fn):
            try:
                fn()
            except Exception as e:
                log.exception("dashboard %s %s", self.command, self.path)
                try:
                    self._send({"error": repr(e)}, code=500)
                except Exception:
                    pass

        def _get(self):
            from urllib.parse import parse_qs, urlparse
            u = urlparse(self.path)
            qs = parse_qs(u.query)
            if u.path == "/":
                return self._send(DASH.read_text(encoding="utf-8"), "text/html; charset=utf-8")
            if u.path == "/api/state":
                try:
                    devs = [n for _, n in list_inputs()]
                except Exception:
                    devs = []
                return self._send(dict(stats=app.history.stats(),
                                       recent=app.history.recent(int(qs.get("limit", ["50"])[0]), qs.get("q", [""])[0]),
                                       cfg=CFG, devices=devs, status=app.status_text, state=app.state,
                                       engine=app.engine.kind, has_key=bool(get_key()),
                                       capturing=app.capturing, hotkey_label=app.hotkey_label,
                                       trusted=app.trusted, mic=mic_status(), sound_choices=SOUND_CHOICES,
                                       version=VERSION))
            if u.path == "/api/check_update":
                return self._send(check_update())
            if u.path == "/api/diagnostics":
                return self._send(diagnostics(app), "text/plain; charset=utf-8",
                                  extra={"Content-Disposition": 'attachment; filename="volcy-voice-diagnostics.txt"'})
            if u.path == "/api/dictionary":
                return self._send(dict(vocab=VOCAB.read_text(encoding="utf-8"), repl=REPL.read_text(encoding="utf-8")))
            if u.path == "/api/export":
                return self._send(app.history.export(), "text/plain; charset=utf-8",
                                  extra={"Content-Disposition": 'attachment; filename="volcy-voice-history.txt"'})
            self._send({"error": "not found"}, code=404)

        def do_POST(self):
            self._safe(self._post)

        def _post(self):
            b = self._body()
            if self.path == "/api/copy_all":
                set_clip(app.history.export())
                return self._send({"ok": True})
            if self.path == "/api/copy_text":
                set_clip(str(b.get("text", "")))
                return self._send({"ok": True})
            if self.path == "/api/copy_diag":
                set_clip(diagnostics(app))
                return self._send({"ok": True})
            if self.path == "/api/update":
                return self._send(start_update())
            if self.path == "/api/copy":
                t = app.history.get(int(b["id"]))
                if t is not None:
                    set_clip(t)
                return self._send({"ok": t is not None})
            if self.path == "/api/delete":
                app.history.delete(int(b["id"]))
                app.menu_dirty = True
                return self._send({"ok": True})
            if self.path == "/api/settings":
                for k, v in b.items():
                    if k in DEFAULTS:
                        CFG[k] = v
                save_config()
                return self._send({"ok": True, "restart": "hotkey" in b})
            if self.path == "/api/dictionary":
                if "vocab" in b:
                    VOCAB.write_text(b["vocab"], encoding="utf-8")
                if "repl" in b:
                    REPL.write_text(b["repl"], encoding="utf-8")
                return self._send({"ok": True})
            if self.path == "/api/play":
                sound(b.get("name"), force=True)
                return self._send({"ok": True})
            if self.path == "/api/capture":
                app.capturing = True
                return self._send({"ok": True})
            if self.path == "/api/hotkey_reset":
                app.set_hotkey(parse_hotkey("alt_r"))
                return self._send({"ok": True})
            if self.path == "/api/open_privacy":
                pane = b.get("pane", "Privacy_Accessibility")
                subprocess.Popen(["open", f"x-apple.systempreferences:com.apple.preference.security?{pane}"])
                subprocess.Popen(["open", "-R", str(Path.home() / "Applications" / "Volcy Voice.app")])
                return self._send({"ok": True})
            if self.path == "/api/key":
                set_key(b.get("key", "").strip())
                return self._send({"ok": bool(get_key())})
            if self.path == "/api/restart":
                self._send({"ok": True})
                subprocess.Popen(["/bin/sh", "-c", 'sleep 2; open -a "$HOME/Applications/Volcy Voice.app"'],
                                 start_new_session=True)
                threading.Timer(0.3, lambda: __import__("os")._exit(0)).start()
                return
            self._send({"error": "not found"}, code=404)
    return H


def open_dashboard():
    url = f"http://127.0.0.1:{CFG['port']}/"
    if Path("/Applications/Google Chrome.app").exists():
        subprocess.Popen(["open", "-na", "Google Chrome", "--args", f"--app={url}", "--window-size=1100,780"])
    else:
        subprocess.Popen(["open", url])


# ---------------------------------------------------------------- the app
class Job:
    def __init__(self, audio, session, app, live=False, flush=False):
        self.audio, self.session, self.app = audio, session, app
        self.live, self.flush = live, flush


def run_app():
    import rumps
    from pynput import keyboard

    class App(rumps.App):
        def __init__(self):
            icon = APPDIR / "menubar_mic.png"
            if icon.exists():
                super().__init__("Volcy Voice", icon=str(icon), template=True, title="…", quit_button=None)
            else:
                super().__init__("Volcy Voice", title="⌛", quit_button=None)
            self.has_icon = icon.exists()
            self.engine = Engine()
            self.history = History()
            self.rec = Recorder()
            self.jobs = queue.Queue()
            self.state, self.status_text = "loading", "Loading speech model…"
            self.recording = self.locked = self.ignore_release = False
            self.pending_tap = None
            self.press_time = 0
            self.session, self.cur_app = "", ""
            self.busy = 0
            self.held_session, self.held_end = None, None
            self.menu_dirty = True
            self.last_text = ""

            self.status_item = rumps.MenuItem(self.status_text)
            self.capturing = False
            self.trusted = accessibility_ok()
            if mic_status() == "undetermined":
                request_mic()
            self.hotkey = parse_hotkey(CFG["hotkey"])
            self.hotkey_label = CFG.get("hotkey_label") or key_label(CFG["hotkey"])
            self.hint_item = rumps.MenuItem(f"Hold {self.hotkey_label} to talk · double-tap for hands-free · Esc cancels")
            self.last_trust_check = 0
            self.recent_menu = rumps.MenuItem("Recent (click to copy)")
            self.recent_menu.add(rumps.MenuItem("Nothing yet"))
            self.mode_release = rumps.MenuItem("Type when I let go", callback=self.set_release)
            self.mode_live = rumps.MenuItem("Type as I speak", callback=self.set_live)
            self.fill_item = rumps.MenuItem("Remove filler words", callback=self.toggle_fillers)
            self.menu = [self.status_item, None,
                         rumps.MenuItem("Open Volcy Voice…", callback=lambda _: open_dashboard()),
                         rumps.MenuItem("Copy last dictation", callback=self.copy_last),
                         rumps.MenuItem("Paste last again", callback=self.paste_last),
                         self.recent_menu, None,
                         self.mode_release, self.mode_live, self.fill_item, None,
                         self.hint_item,
                         None, rumps.MenuItem("Quit Volcy Voice", callback=rumps.quit_application)]
            self.sync_checks()

            threading.Thread(target=self.worker, daemon=True).start()
            srv = ThreadingHTTPServer(("127.0.0.1", CFG["port"]), make_handler(self))
            threading.Thread(target=srv.serve_forever, daemon=True).start()
            self.Key = keyboard.Key
            log.info("started; accessibility trusted=%s hotkey=%s", self.trusted, CFG["hotkey"])
            keyboard.Listener(on_press=self.on_press, on_release=self.on_release).start()
            rumps.Timer(self.tick, 0.15).start()
            if not (HOME / ".seen_v2").exists():
                (HOME / ".seen_v2").touch()
                threading.Timer(2, open_dashboard).start()

        # ---- menu
        def sync_checks(self):
            self.mode_release.state = CFG["mode"] == "release"
            self.mode_live.state = CFG["mode"] == "live"
            self.fill_item.state = bool(CFG["remove_fillers"])

        def set_release(self, _):
            CFG["mode"] = "release"; save_config(); self.sync_checks()

        def set_live(self, _):
            CFG["mode"] = "live"; save_config(); self.sync_checks()

        def toggle_fillers(self, _):
            CFG["remove_fillers"] = not CFG["remove_fillers"]; save_config(); self.sync_checks()

        def copy_last(self, _):
            r = self.history.recent(1)
            if r:
                set_clip(r[0]["text"])

        def paste_last(self, _):
            r = self.history.recent(1)
            if r:
                threading.Thread(target=type_text, args=(r[0]["text"] + " ",), daemon=True).start()

        def set_hotkey(self, key):
            CFG["hotkey"] = key_to_str(key)
            save_config()
            self.hotkey = key
            self.hotkey_label = key_label(CFG["hotkey"], key)
            CFG["hotkey_label"] = self.hotkey_label
            save_config()
            self.hint_item.title = f"Hold {self.hotkey_label} to talk · double-tap for hands-free · Esc cancels"
            log.info("hotkey set to %s (%s)", CFG["hotkey"], self.hotkey_label)

        def tick(self, _):
            if time.time() - self.last_trust_check > 3:
                self.last_trust_check = time.time()
                t = accessibility_ok()
                if t != self.trusted:
                    self.trusted = t
                    if t:
                        log.info("accessibility granted; relaunching so the key listener picks it up")
                        subprocess.Popen(["/bin/sh", "-c", "sleep 1.5; open -a 'Volcy Voice'"])
                        rumps.quit_application()
                        return
                if not t and self.state != "loading":
                    self.status_text = "Needs Accessibility: add Volcy Voice in Privacy & Security"
            if self.has_icon:   # mic glyph always shows; a small badge beside it shows the state
                icon = {"loading": "…", "idle": None, "rec": "●", "locked": "●∞", "error": "!"}.get(self.state)
                if self.state == "idle" and self.busy:
                    icon = "✍︎"
                if self.state == "idle" and (not self.trusted or "blocked" in self.status_text):
                    icon = "!"
            else:
                icon = {"loading": "⌛", "idle": "🎙", "rec": "🔴", "locked": "🔴∞", "work": "✍️",
                        "error": "⚠️"}.get(self.state, "🎙")
                if self.state == "idle" and self.busy:
                    icon = "✍️"
            if self.title != icon:
                self.title = icon
            if self.status_item.title != self.status_text:
                self.status_item.title = self.status_text
            if self.menu_dirty:
                self.menu_dirty = False
                self.sync_checks()
                self.recent_menu.clear()
                items = self.history.recent(8)
                if not items:
                    self.recent_menu.add(rumps.MenuItem("Nothing yet"))
                for it in items:
                    label = it["text"].replace("\n", " ")
                    label = (label[:60] + "…") if len(label) > 60 else label
                    self.recent_menu.add(rumps.MenuItem(label, callback=lambda _, t=it["text"]: set_clip(t)))

        # ---- worker: the ONLY thread that touches the model
        def worker(self):
            try:
                self.engine.load()
                self.state = "idle"
                self.status_text = f"Ready · {'Apple GPU' if self.engine.kind == 'mlx' else 'CPU'} · offline"
            except Exception as e:
                log.exception("model load")
                self.state, self.status_text = "error", f"Model error: {e}"[:90]
                return
            while True:
                job = self.jobs.get()
                if job.flush:     # end of an "as I speak" session: put back the period we held
                    if self.held_session == job.session:
                        if self.held_end is not None:
                            type_text(self.held_end + " ")
                        self.held_session, self.held_end = None, None
                    continue
                self.busy += 1
                try:
                    t = time.time()
                    raw = self.engine.transcribe(job.audio)
                    text = clean(raw)
                    lat = time.time() - t
                    log.info("transcribed %.1fs audio in %.2fs: %r", len(job.audio) / SR, lat, raw)
                    if text and not is_hallucination(text):
                        self.type_out(text, job)
                        self.history.add(job.session, text, raw, job.app, len(job.audio) / SR, lat)
                        self.menu_dirty = True
                        where = "online" if getattr(self.engine, "used", "") == "cloud" else "on this Mac"
                        self.status_text = f"Ready · last one took {lat:.1f}s ({where})"
                    else:
                        self.status_text = "Didn't catch any words. Try again a little closer to the mic."
                except Exception as e:
                    log.exception("transcribe")
                    self.status_text = f"Error: {e}"[:90]
                finally:
                    self.busy -= 1

        def type_out(self, text, job):
            if text.endswith("\n"):
                self.held_session, self.held_end = None, None
                return type_text(text)
            if not job.live:
                return type_text(fit_to_cursor(text) + " ")
            # As I speak: hold each phrase's final period until we hear what comes next, so a
            # pause mid-sentence doesn't leave "I went to the store. And bought milk."
            if self.held_session == job.session and self.held_end is not None:
                first = re.match(r"[A-Za-z']+", text)
                if self.held_end == "." and first and first.group(0).lower() in CONTINUE_WORDS:
                    prefix = " "
                    text = text[0].lower() + text[1:]
                else:
                    prefix = self.held_end + " "
            else:
                prefix, text = "", fit_to_cursor(text)
            end = ""
            if text.endswith(".") and not text.endswith(".."):
                text, end = text[:-1], "."
            self.held_session, self.held_end = job.session, end
            type_text(prefix + text)

        def submit(self, audio, peak, live=False):
            if audio is None or len(audio) < SR * 0.25:
                return False
            if peak < CFG["silence_threshold"]:
                if mic_status() == "denied":
                    self.status_text = "Microphone blocked: allow Volcy Voice in Privacy & Security > Microphone"
                else:
                    self.status_text = f"Too quiet ({self.rec.device_name}, level {peak:.4f}). Check the mic in Settings."
                return False
            self.jobs.put(Job(audio, self.session, self.cur_app, live=live))
            return True

        # ---- recording
        def start_rec(self):
            if self.state in ("loading", "error"):
                sound("Basso")
                return
            try:
                self.session = f"{time.time():.3f}"
                self.cur_app = front_app()
                self.rec.start()
                self.recording = True
                self.state = "rec"
                sound(CFG["start_sound"])
                if CFG["mode"] == "live":
                    threading.Thread(target=self.live_loop, daemon=True).start()
            except Exception as e:
                log.exception("start recording")
                self.status_text = f"Mic error: {e}"[:90]
                self.recording = False

        def finish(self):
            self.recording = self.locked = False
            self.pending_tap = None
            self.rec.stop()
            sound(CFG["stop_sound"])
            audio, peak = self.rec.take()
            self.state = "idle"
            live = CFG["mode"] == "live"
            self.submit(audio, peak, live=live)
            if live:
                self.jobs.put(Job(None, self.session, self.cur_app, flush=True))

        def cancel(self):
            self.recording = self.locked = False
            self.pending_tap = None
            self.rec.stop()
            self.rec.take()
            self.state = "idle"

        def live_loop(self):
            blk = Recorder.BLOCK
            while self.recording:
                time.sleep(0.1)
                with self.rec.lock:
                    n = len(self.rec.rms)
                    rms = self.rec.rms[self.rec.cut:n]
                tail = int(CFG["live_pause"] / blk)
                if len(rms) < int(1.0 / blk) + tail:
                    continue
                thr = CFG["silence_threshold"]
                if max(rms[:-tail]) > thr and max(rms[-tail:]) <= thr:
                    audio, peak = self.rec.take(n)
                    self.submit(audio, peak, live=True)

        def on_press(self, key):
            try:
                if self.capturing:
                    if key == self.Key.esc:
                        self.capturing = False
                        return
                    self.capturing = False
                    self.set_hotkey(key)
                    self.ignore_release = True
                    sound("Glass")
                    return
                if key == self.Key.esc and self.recording:
                    sound("Funk")
                    return self.cancel()
                if not same_key(key, self.hotkey):
                    return
                now = time.time()
                if self.locked:
                    self.ignore_release = True
                    return self.finish()
                if self.recording:
                    if self.pending_tap and now - self.pending_tap < 0.45:
                        self.locked, self.pending_tap, self.ignore_release = True, None, True
                        self.state = "locked"
                        sound("Morse")
                    return
                self.press_time = now
                self.start_rec()
            except Exception:
                log.exception("on_press")

        def on_release(self, key):
            try:
                if not same_key(key, self.hotkey):
                    return
                if self.ignore_release:
                    self.ignore_release = False
                    return
                if not self.recording or self.locked:
                    return
                if time.time() - self.press_time < 0.3:      # a tap: maybe the first half of a double-tap
                    t = self.pending_tap = time.time()
                    threading.Timer(0.45, self._tap_timeout, args=(t,)).start()
                    return
                self.finish()
            except Exception:
                log.exception("on_release")

        def _tap_timeout(self, t):
            if self.pending_tap == t and self.recording and not self.locked:
                self.cancel()

    App().run()


# ---------------------------------------------------------------- self test
def self_test():
    print("Inputs:", list_inputs())
    rec = Recorder()
    rec.start()
    print(f"Recording 5 seconds from: {rec.device_name}. Speak now…")
    time.sleep(5)
    rec.stop()
    audio, peak = rec.take()
    print(f"Peak level {peak:.3f} (threshold {CFG['silence_threshold']})")
    eng = Engine()
    print("Loading model…")
    eng.load()
    t = time.time()
    raw = eng.transcribe(audio)
    print(f"Raw ({time.time() - t:.2f}s): {raw!r}")
    print(f"Clean: {clean(raw)!r}")
    print("Pasting into the frontmost app in 3 seconds… (click into a text box now)")
    time.sleep(3)
    type_text(clean(raw) + " ")
    print("Done.")


if __name__ == "__main__":
    try:
        if "--test" in sys.argv:
            self_test()
        else:
            run_app()
    except Exception:
        log.error(traceback.format_exc())
        raise
