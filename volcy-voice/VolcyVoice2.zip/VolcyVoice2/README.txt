VOLCY VOICE 2 - private, unlimited dictation for your Mac

INSTALL (upgrades the old version in place)
1. Unzip. Right-click install.command > Open.
2. When it finishes, Finder shows "Volcy Voice" in your Applications folder (in your home folder).
3. System Settings > Privacy & Security:
   - Accessibility: click +, pick Volcy Voice, switch on.
   - Input Monitoring: same.
   - Allow the Microphone prompt.
4. Menu bar mic > Quit, then double-click Volcy Voice to start it again.

USE
- Hold RIGHT OPTION (or the key you pick in Settings > Hold-to-talk key), talk, let go. The text is typed where your cursor is.
- Double-tap RIGHT OPTION for hands-free. Tap once more to finish.
- Esc cancels.
- Menu bar: 🎙 ready · 🔴 listening · 🔴∞ hands-free · ✍️ writing · ⚠️ problem (the menu says what).

DASHBOARD (menu bar > Open Volcy Voice…)
- Home: time saved, word count, and recent dictations with a Copy button.
- History: search everything, copy, delete, Export all.
- Dictionary: names and words to spell right, plus "heard => written" fixes.
- Settings: type when you let go, or as you speak; remove fillers; voice commands
  ("new line", "new paragraph"); microphone; language (incl. Kreyòl); hotkey.

TIP: the MacBook mic beats AirPods for dictation. AirPods drop to phone-call quality
and take a second to wake, which clips your first words. The app picks the MacBook mic by default.

TROUBLESHOOTING
  ~/VolcyVoice/venv/bin/python ~/VolcyVoice/volcy_voice.py --test
records 5 seconds, prints what it heard, and pastes it. Errors are logged in ~/.volcy_voice/log.txt

INSTANT MODE (optional, online)
Settings > Instant mode. Paste a Groq API key (free signup at console.groq.com/keys).
Under a second per dictation with Whisper Large v3 Turbo; costs pennies a month.
If you're offline it quietly uses the on-Mac model instead.
