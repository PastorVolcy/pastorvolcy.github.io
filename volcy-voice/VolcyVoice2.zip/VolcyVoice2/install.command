#!/bin/bash
# Volcy Voice installer. Double-click (or right-click > Open). Safe to run again; it upgrades in place.
set -e
cd "$(dirname "$0")"
DEST="$HOME/VolcyVoice"
APP="$HOME/Applications/Volcy Voice.app"
echo "== Volcy Voice =="

launchctl unload "$HOME/Library/LaunchAgents/com.volcy.voice.plist" 2>/dev/null || true
pkill -f "volcy_voice.py" 2>/dev/null || true
pkill -f "Volcy Voice.app" 2>/dev/null || true

PY=""
for p in /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  [ -x "$p" ] && PY="$p" && break
done
if [ -z "$PY" ]; then echo "Python not found. Installing Apple's tools; run this again after."; xcode-select --install; exit 1; fi

mkdir -p "$DEST" "$HOME/Applications" "$HOME/.volcy_voice"
cp volcy_voice.py dashboard.html *.wav menubar_mic.png VolcyVoice.icns "$DEST/"
rm -f "$DEST/start.wav" "$DEST/stop.wav"
[ -x "$DEST/venv/bin/python" ] || "$PY" -m venv "$DEST/venv"
source "$DEST/venv/bin/activate"
pip install --upgrade pip -q
COMMON="rumps pynput sounddevice numpy pyobjc-framework-Quartz pyobjc-framework-Cocoa pyobjc-framework-AVFoundation pyobjc-framework-ApplicationServices py2app"
if [ "$(uname -m)" = "arm64" ]; then pip install -q --upgrade mlx-whisper $COMMON; else pip install -q --upgrade faster-whisper $COMMON; fi

echo "Checking the speech model (downloads once)…"
python - <<'PY'
import platform, numpy as np
if platform.machine()=="arm64":
    import mlx_whisper; mlx_whisper.transcribe(np.zeros(16000,dtype=np.float32), path_or_hf_repo="mlx-community/whisper-large-v3-turbo")
else:
    from faster_whisper import WhisperModel; WhisperModel("small.en", device="cpu", compute_type="int8")
print("Model ready.")
PY

echo "Building the Volcy Voice app…"
cd "$DEST"
cat > setup.py <<'PY'
from setuptools import setup
setup(
    app=["volcy_voice.py"],
    name="Volcy Voice",
    options={"py2app": {
        "iconfile": "VolcyVoice.icns",
        "plist": {
            "CFBundleName": "Volcy Voice",
            "CFBundleDisplayName": "Volcy Voice",
            "CFBundleIdentifier": "church.firstalliance.volcyvoice",
            "CFBundleShortVersionString": "2.1",
            "CFBundleVersion": "2.1",
            "LSUIElement": True,
            "NSMicrophoneUsageDescription": "Volcy Voice listens only while you hold your talk key. Everything stays on this Mac unless you turn on Instant mode.",
            "NSAppleEventsUsageDescription": "Volcy Voice types your words into the app you're using.",
        },
    }},
)
PY
rm -rf build dist
BUILT=0
if [ -f "$APP/Contents/Resources/__boot__.py" ] && [ -z "$REBUILD" ]; then
  # The app links to the files in ~/VolcyVoice, so updates need no rebuild, and macOS keeps your permissions.
  echo "App already built; updated its code in place."; BUILT=1
elif python setup.py -q py2app -A >"$HOME/.volcy_voice/build.log" 2>&1 && [ -d "dist/Volcy Voice.app" ]; then
  rm -rf "$APP"; cp -R "dist/Volcy Voice.app" "$APP"; BUILT=2
  rm -rf build dist   # leave only one copy of the app, so Finder and Spotlight show one icon
else
  echo "(App build fell back to the simple launcher; details in ~/.volcy_voice/build.log)"
  rm -rf "$APP"; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
  cp VolcyVoice.icns "$APP/Contents/Resources/"
  cat > "$APP/Contents/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Volcy Voice</string>
<key>CFBundleIdentifier</key><string>church.firstalliance.volcyvoice</string>
<key>CFBundleExecutable</key><string>VolcyVoice</string>
<key>CFBundleIconFile</key><string>VolcyVoice</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>LSUIElement</key><true/>
<key>NSMicrophoneUsageDescription</key><string>Volcy Voice listens only while you hold your talk key.</string>
</dict></plist>
PL
  printf '#!/bin/bash\nexec "%s/venv/bin/python" "%s/volcy_voice.py" >>"$HOME/.volcy_voice/log.txt" 2>&1\n' "$DEST" "$DEST" > "$APP/Contents/MacOS/VolcyVoice"
  chmod +x "$APP/Contents/MacOS/VolcyVoice"
fi
# Old copies from earlier installs
for OLD in "/Applications/Volcy Voice.app" "$HOME/Applications/VolcyVoice.app" "$HOME/Desktop/Volcy Voice.app"; do
  if [ -e "$OLD" ]; then rm -rf "$OLD" 2>/dev/null && echo "Removed old copy: $OLD" || true; fi
done
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -u "$DEST/dist/Volcy Voice.app" 2>/dev/null || true
if [ ! -f "$HOME/.volcy_voice/.signed" ] || [ -n "$REBUILD" ] || [ "$BUILT" = "2" ]; then codesign --force --deep -s - "$APP" 2>/dev/null || true; touch "$HOME/.volcy_voice/.signed"; fi

PLIST="$HOME/Library/LaunchAgents/com.volcy.voice.plist"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>com.volcy.voice</string>
<key>ProgramArguments</key><array><string>/usr/bin/open</string><string>-a</string><string>$APP</string></array>
<key>RunAtLoad</key><true/>
</dict></plist>
PL
launchctl load "$PLIST"

echo ""
echo "Done. The mic is in your menu bar."
echo "If macOS asks for the Microphone, click Allow. If the dashboard shows a red banner,"
echo "use its buttons to switch on Volcy Voice under Accessibility and Input Monitoring."
