#!/bin/bash
launchctl unload "$HOME/Library/LaunchAgents/com.volcy.voice.plist" 2>/dev/null
pkill -f "VolcyVoice/volcy_voice.py" 2>/dev/null
rm -f "$HOME/Library/LaunchAgents/com.volcy.voice.plist"
rm -rf "$HOME/VolcyVoice" "$HOME/Applications/Volcy Voice.app"
echo "Volcy Voice removed. Your history, dictionary and settings are kept in ~/.volcy_voice"
